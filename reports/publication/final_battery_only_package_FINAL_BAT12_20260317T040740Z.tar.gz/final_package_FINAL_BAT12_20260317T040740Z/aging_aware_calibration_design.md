# Aging-Aware Calibration Design

- Rolling conformity store with EWMA decay (alpha configurable).
- Age-conditioned calibration buckets with effective sample size tracking.
- Conservative width multiplier when bucket support is low.
- Audit fields: bucket_id, ewma_alpha, effective_n, width_multiplier.
