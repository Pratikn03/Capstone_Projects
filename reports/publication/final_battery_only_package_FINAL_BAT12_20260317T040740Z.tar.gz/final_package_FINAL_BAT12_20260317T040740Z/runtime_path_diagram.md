# Runtime Path Diagram

```mermaid
flowchart TD
  telemetry[TelemetryEvent] --> oqe[OQE_Reliability]
  oqe --> rac[RAC_Inflation]
  rac --> solver[DispatchSolver]
  solver --> saf[SafeActionRepair]
  saf --> cert[CertificateEmit]
  cert --> ledger[AuditLedger]
```
