# Quality-Score Gossip Protocol (Battery Fleet)

- local state: reliability_w, certificate_validity_horizon, safety_margin_mw
- broadcast message: battery_id, reliability_bucket, urgent_flag
- coordination rule: reduce shared-transformer margin when any urgent_flag=true
- fallback: coordinated safe discharge cap with fairness regularization
