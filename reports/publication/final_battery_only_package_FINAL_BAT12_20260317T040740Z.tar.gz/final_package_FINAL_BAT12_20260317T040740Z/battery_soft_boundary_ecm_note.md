# Battery Soft Boundary and ECM-Compatible Note

- Uses stress-weighted penalties near SOC limits instead of hard-wall-only interpretation.
- Maps linear SOC plant to an ECM-compatible feasible-set overlay for voltage/current-aware reasoning.
- Connects controller repair actions to boundary stress reduction and asset-preservation proxies.
- Source anchors: `src/gridpulse/cpsbench_iot/plant.py`, `src/gridpulse/optimizer/`.
