# Battery Adversarial Threat Model

- spoof: bounded sensor value manipulation
- replay: stale packet reuse as fresh telemetry
- selective dropout: packet omission to bias observed state
- non-capabilities: no direct plant or certificate-chain tampering
- active probing: bounded action perturbation with SOC-response consistency check
